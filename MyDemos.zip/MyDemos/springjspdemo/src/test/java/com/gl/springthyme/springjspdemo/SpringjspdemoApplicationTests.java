package com.gl.springthyme.springjspdemo;

import org.junit.jupiter.api.Test;
import org.springframework.boot.test.context.SpringBootTest;

@SpringBootTest
class SpringjspdemoApplicationTests {

	@Test
	void contextLoads() {
	}

}

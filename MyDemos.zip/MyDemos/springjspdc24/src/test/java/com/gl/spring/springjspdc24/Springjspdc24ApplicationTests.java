package com.gl.spring.springjspdc24;

import org.junit.jupiter.api.Test;
import org.springframework.boot.test.context.SpringBootTest;

@SpringBootTest
class Springjspdc24ApplicationTests {

	@Test
	void contextLoads() {
	}

}

package com.gl.springjsp.springdemo24d;

import org.springframework.boot.SpringApplication;
import org.springframework.boot.autoconfigure.SpringBootApplication;

@SpringBootApplication(scanBasePackages={"com.gl.springjsp.springdemo24d"})
public class Springdemo24dApplication {

	public static void main(String[] args) {
		SpringApplication.run(Springdemo24dApplication.class, args);
	}

}

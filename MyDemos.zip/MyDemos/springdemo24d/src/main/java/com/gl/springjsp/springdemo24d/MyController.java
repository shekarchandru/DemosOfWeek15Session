package com.gl.springjsp.springdemo24d;

import org.springframework.stereotype.Controller;
import org.springframework.ui.Model;
import org.springframework.web.bind.annotation.RequestMapping;

@Controller
@RequestMapping("/hello")
public class MyController {
	
	@RequestMapping("/greet")
	public String sayHello(Model model)
	{
		String greetings = "Hi! Welcome to SpringBoot...";
		model.addAttribute("greeting", greetings);
		return "welcome";
		
	}

}

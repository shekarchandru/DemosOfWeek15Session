package com.gl.springjsp.springdemo24d;

import org.junit.jupiter.api.Test;
import org.springframework.boot.test.context.SpringBootTest;

@SpringBootTest
class Springdemo24dApplicationTests {

	@Test
	void contextLoads() {
	}

}

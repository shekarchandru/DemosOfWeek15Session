package com.gl.springrest.restfulapp24d;

import org.junit.jupiter.api.Test;
import org.springframework.boot.test.context.SpringBootTest;

@SpringBootTest
class Restfulapp24dApplicationTests {

	@Test
	void contextLoads() {
	}

}

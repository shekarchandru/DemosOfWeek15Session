package com.gl.springrest.restfulapp24d;

import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RestController;

@RestController
@RequestMapping("/libms")
public class MyController {
	
	@RequestMapping("/greet")
	public String sayHello()
	{
		return "Welcome to RESTFUL API...";
	}

}

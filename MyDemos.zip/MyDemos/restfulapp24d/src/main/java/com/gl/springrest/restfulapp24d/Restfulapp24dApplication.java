package com.gl.springrest.restfulapp24d;

import org.springframework.boot.SpringApplication;
import org.springframework.boot.autoconfigure.SpringBootApplication;

@SpringBootApplication
public class Restfulapp24dApplication {

	public static void main(String[] args) {
		SpringApplication.run(Restfulapp24dApplication.class, args);
	}

}
